package com.vehicle.test;
import com.vehicle.Car;
import com.vehicle.ElectricCar;

public class VehicleTest {
    public static void main(String[] args) {
        Car car = new Car();
        car.setSpeed(120.0);
        car.setFuelLevel(25.0f);
        car.drive(5000);

        // Display car information
        System.out.println("Car speed in MPH: " + car.getSpeedMph());
        System.out.println("Car distance traveled in KM: " + car.getDistanceKm());
        System.out.println("Car remaining fuel: " + car.calculateRemainingFuel(5.0) + "%");

        // Create an instance of ElectricCar
        ElectricCar electricCar = new ElectricCar();
        electricCar.setSpeed(80.0); // Speed in kilometers per hour
        electricCar.setBatteryLevel(50.0); // Battery level as percentage
        electricCar.drive(20000); // Drive 20000 meters

        // Display electric car information
        System.out.println("Electric Car speed in MPH: " + electricCar.getSpeedMph());
        System.out.println("Electric Car distance traveled in KM: " + electricCar.getDistanceKm());
        System.out.println("Electric Car remaining battery: " + electricCar.getBatteryLevel()+ "%");
    }
}
