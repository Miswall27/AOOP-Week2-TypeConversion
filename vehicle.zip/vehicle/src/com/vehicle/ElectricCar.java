package com.vehicle;
//extends is used to define subclass
public class ElectricCar extends Car {
    private double batteryLevel;
    public void setBatteryLevel(double battery){
this.batteryLevel=battery;
    }
    public double getBatteryLevel(){
return batteryLevel;
    }
    public void drive(int distance) //battery level by 1% for every 10 kilometers driven
    {
        super.drive(distance);
        batteryLevel -= (distance / 10000.0);
    }
}
