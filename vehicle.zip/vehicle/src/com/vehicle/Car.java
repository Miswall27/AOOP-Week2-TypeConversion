package com.vehicle;

public class Car {
    private double speedKph;
    private float fuelLevel;
    private int distanceTraveled;

    public void setSpeed(double speed) {
        this.speedKph = speed;
    }

    public void setFuelLevel(float fuelLevel1) {
        this.fuelLevel = fuelLevel1;
    }

    public void drive(int distance) {
        this.distanceTraveled += distance;
    }

    public double getSpeedMph() {
        double v = speedKph / 1.60934;
        return v;
    }

    public int getDistanceKm() {
        int d = distanceTraveled / 1000;
        return d;
    }

    public int calculateRemainingFuel(double distance) {
        // Calculating fuel consumption based on the given distance (in kilometers)
        do {
            double fuelConsumption = distance * 0.5; // Consuming 0.5% fuel per km
            fuelLevel -= (float) fuelConsumption;
            return (int) fuelLevel;
        }
        while (fuelLevel > 0);
    }

}



